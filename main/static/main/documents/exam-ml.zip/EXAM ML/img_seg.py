import cv2
import numpy as np

# 1. Read image
image = cv2.imread("meter.jpg")

# 2. Check if image loaded
if image is None:
    print("Image not found. Check file name or path.")
    exit()

# 3. Convert image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 4. Apply Gaussian Blur to reduce noise
blurred = cv2.GaussianBlur(gray, (7, 7), 0)

# 5. Simple Binary Thresholding
# If pixel value > 45, make it white 255
# Else make it black 0
T, thresh = cv2.threshold(blurred, 45, 255, cv2.THRESH_BINARY)

# 6. Inverse Binary Thresholding
# Opposite of normal threshold
T_inv, thresh_inv = cv2.threshold(blurred, 45, 255, cv2.THRESH_BINARY_INV)

# 7. Otsu Thresholding
# OpenCV automatically chooses the best threshold value
T_otsu, thresh_otsu = cv2.threshold(
    blurred,
    0,
    255,
    cv2.THRESH_BINARY | cv2.THRESH_OTSU
)

# 8. Otsu Inverse Thresholding
T_otsu_inv, thresh_otsu_inv = cv2.threshold(
    blurred,
    0,
    255,
    cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU
)

# 9. Masking
# Keep only the selected white area from the original image
masked = cv2.bitwise_and(image, image, mask=thresh_otsu_inv)

# 10. Show results
cv2.imshow("Original Image", image)
cv2.imshow("Gray Image", gray)
cv2.imshow("Blurred Image", blurred)
cv2.imshow("Simple Threshold", thresh)
cv2.imshow("Inverse Threshold", thresh_inv)
cv2.imshow("Otsu Threshold", thresh_otsu)
cv2.imshow("Otsu Inverse Threshold", thresh_otsu_inv)
cv2.imshow("Masked Image", masked)

# 11. Save results
cv2.imwrite("gray.jpg", gray)
cv2.imwrite("blurred.jpg", blurred)
cv2.imwrite("simple_threshold.jpg", thresh)
cv2.imwrite("inverse_threshold.jpg", thresh_inv)
cv2.imwrite("otsu_threshold.jpg", thresh_otsu)
cv2.imwrite("otsu_inverse_threshold.jpg", thresh_otsu_inv)
cv2.imwrite("masked_result.jpg", masked)

# 12. Wait and close windows
cv2.waitKey(0)
cv2.destroyAllWindows()