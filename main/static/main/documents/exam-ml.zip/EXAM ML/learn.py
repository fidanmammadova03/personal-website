import cv2

image = cv2.imread("image.jpg")


gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

blurred = cv2.GaussianBlur(image, (7, 7), 0)

t_otsu, thresh_otsu = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

masked = cv2.bitwise_and(image, image, mask = thresh_otsu)

cv2.imshow("Original Image", image)


cv2.imwrite("gray.jpg", gray)

cv2.waitKey(0)

cv2.destroyAllWindows()