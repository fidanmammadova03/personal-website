import cv2

# Read image
img = cv2.imread("nasa.jpg")

# Convert to grayscale
gray_img = cv2.cvtColor(
    img,
    cv2.COLOR_BGR2GRAY
)

# Load Haar Cascade XML
haar_cascade = cv2.CascadeClassifier(
    "Haarcascade_frontalface_default.xml"
)

# Detect faces
faces_rect = haar_cascade.detectMultiScale(
    gray_img,
    1.1,
    9
)

# Draw rectangles
for (x, y, w, h) in faces_rect:

    cv2.rectangle(
        img,
        (x, y),
        (x + w, y + h),
        (0, 255, 0),
        2
    )

# Show result
cv2.imshow("Detected Faces", img)

cv2.waitKey(0)
cv2.destroyAllWindows()