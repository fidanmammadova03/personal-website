import cv2

# 1. Read two images
img1 = cv2.imread("image1.jpg")
img2 = cv2.imread("image2.jpg")

# 2. Check images
if img1 is None or img2 is None:
    print("Image not found. Check image1.jpg and image2.jpg")
    exit()

# 3. Convert images to grayscale
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

# 4. Create SURF detector
# Important: SURF may need opencv-contrib-python
surf = cv2.xfeatures2d.SURF_create(400)

# 5. Detect keypoints and descriptors
kp1, des1 = surf.detectAndCompute(gray1, None)
kp2, des2 = surf.detectAndCompute(gray2, None)

# 6. Draw keypoints for each image
surf_img1 = cv2.drawKeypoints(
    img1,
    kp1,
    None,
    (0, 255, 0),
    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS
)

surf_img2 = cv2.drawKeypoints(
    img2,
    kp2,
    None,
    (0, 255, 0),
    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS
)

# 7. Match descriptors using BFMatcher
bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)
matches = bf.match(des1, des2)

# 8. Sort matches by distance
matches = sorted(matches, key=lambda x: x.distance)

# 9. Draw best matches
matched_image = cv2.drawMatches(
    img1,
    kp1,
    img2,
    kp2,
    matches[:50],
    None,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# 10. Print results
print("SURF keypoints in image 1:", len(kp1))
print("SURF keypoints in image 2:", len(kp2))
print("Number of SURF matches:", len(matches))

# 11. Show results
cv2.imshow("SURF Keypoints Image 1", surf_img1)
cv2.imshow("SURF Keypoints Image 2", surf_img2)
cv2.imshow("SURF Matches", matched_image)

# 12. Save results
cv2.imwrite("surf_keypoints_image1.jpg", surf_img1)
cv2.imwrite("surf_keypoints_image2.jpg", surf_img2)
cv2.imwrite("surf_matches.jpg", matched_image)

# 13. Wait and close
cv2.waitKey(0)
cv2.destroyAllWindows()