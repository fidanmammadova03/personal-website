import cv2
import numpy as np

# Load image
image = cv2.imread('object.jpg')

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Blur image to reduce noise
blur = cv2.GaussianBlur(gray, (11, 11), 0)

# Edge detection
canny = cv2.Canny(blur, 30, 150)

# Dilate edges
dilated = cv2.dilate(canny, (1, 1), iterations=2)

# Find contours
contours, hierarchy = cv2.findContours(
    dilated.copy(),
    cv2.RETR_EXTERNAL,
    cv2.CHAIN_APPROX_NONE
)

# Count objects
print("Number of objects found:", len(contours))

# Draw contours
cv2.drawContours(
    image,
    contours,
    -1,
    (0, 255, 0),
    2
)

# Show image
cv2.imshow("Objects", image)

cv2.waitKey(0)
cv2.destroyAllWindows()